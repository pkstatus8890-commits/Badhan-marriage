import { db } from "@workspace/db";
import {
  appSettings,
  casteCategories,
  castesCommunities,
  courseCategories,
  searchableFields,
  subscriptionPlans,
} from "@workspace/db";

const categoryNames = ["Caste", "Sub-caste", "Community", "Other"];
const communityNames = [
  "Agarwal", "Agri", "Ahir", "Arora", "Arya Samaj", "Audichya Brahmin", "Baidya", "Bania", "Baniya", "Bengali Brahmin",
  "Bhandari", "Bhatia", "Brahmin", "Bunt", "Chamar", "Chandravanshi", "Chettiar", "Chitpavan Brahmin", "CKP", "Devanga",
  "Dhobi", "Ezhava", "Gaur Brahmin", "Gounder", "Gujarati", "Gurjar", "Jain", "Jat", "Jatav", "Kamma", "Kannada Brahmin",
  "Kanyakubja Brahmin", "Kayastha", "Khatri", "Koli", "Konkani", "Kshatriya", "Kurmi", "Lingayat", "Lohana", "Lodhi",
  "Madhwa Brahmin", "Maheshwari", "Mahar", "Mali", "Maratha", "Marwari", "Matang", "Meena", "Menon", "Modh Bania",
  "Mudaliar", "Mukkuvar", "Nadar", "Nair", "Naidu", "OBC community (self-described)", "Oswal", "Panchal", "Patel",
  "Prajapati", "Rajput", "Reddy", "Scheduled Caste (self-described)", "Scheduled Tribe (self-described)", "Shah",
  "Shetty", "Sindhi", "Smartha Brahmin", "Sonar", "Sourashtra", "Sutar", "Tamil Brahmin", "Teli", "Thakur", "Tiwari",
  "Vanniyar", "Vaishnav", "Valmiki", "Vokkaliga", "Vishwakarma", "Yadav", "Iyer", "Iyengar", "Other", "Prefer not to say",
];

const searchable = [
  ["name", "Name"], ["age", "Age"], ["gender", "Gender"], ["city", "City"], ["state", "State"],
  ["community", "Caste / Community"], ["education", "Education"], ["profession", "Profession"],
  ["marital_status", "Marital status"], ["gotra", "Gotra"], ["profile_status", "Profile status"],
];

let seedPromise: Promise<void> | undefined;
export function ensureBandhanCatalog(): Promise<void> {
  if (!seedPromise) {
    seedPromise = (async () => {
      await db.insert(casteCategories)
        .values(categoryNames.map((name, sortOrder) => ({ name, sortOrder })))
        .onConflictDoNothing();
      await db.insert(castesCommunities)
        .values(communityNames.map((name) => ({ name, stateCoverage: [] })))
        .onConflictDoNothing();
      await db.insert(subscriptionPlans).values([
        {
          name: "Free Member", monthlyPrice: "0", durationDays: 30,
          features: ["Browse approved profiles", "Send connection requests", "5 messages per accepted connection"],
          messageLimit: 5, profileVisibility: "standard", advancedSearch: false, priorityListing: false,
        },
        {
          name: "Limited Chat", monthlyPrice: "200", durationDays: 30,
          features: ["Browse all approved profiles", "20 messages per accepted connection", "Advanced search filters"],
          messageLimit: 20, profileVisibility: "standard", advancedSearch: true, priorityListing: false,
        },
        {
          name: "More Chat", monthlyPrice: "500", durationDays: 30,
          features: ["Browse all approved profiles", "100 messages per accepted connection", "Advanced search filters", "Priority listing"],
          messageLimit: 100, profileVisibility: "priority", advancedSearch: true, priorityListing: true,
        },
        {
          name: "Prime / Full Chat", monthlyPrice: "1000", durationDays: 30,
          features: ["Browse all approved profiles", "Unlimited messages in accepted conversations", "Advanced search filters", "Featured profile visibility"],
          messageLimit: null, unlimitedMessaging: true, profileVisibility: "featured", advancedSearch: true, priorityListing: true,
        },
      ]).onConflictDoNothing();
      await db.insert(courseCategories)
        .values(["Communication", "Family & relationships", "Safety & privacy", "Financial readiness", "Other"].map((name, sortOrder) => ({ name, sortOrder })))
        .onConflictDoNothing();
      await db.insert(searchableFields)
        .values(searchable.map(([key, label], sortOrder) => ({ key, label, sortOrder, enabled: true })))
        .onConflictDoNothing();
      await db.insert(appSettings).values([
        { key: "free_message_limit", value: "5" },
        { key: "premium_message_limit", value: "100" },
        { key: "premium_unlimited_messaging", value: "true" },
      ]).onConflictDoNothing();
    })().catch((error: unknown) => {
      seedPromise = undefined;
      throw error;
    });
  }
  return seedPromise;
}
