import { createHash, randomBytes } from "node:crypto";
import type { Request, Response } from "express";
import { and, eq, gt, isNull } from "drizzle-orm";
import { db, memberSessions, users } from "@workspace/db";

export const MEMBER_COOKIE = "bandhan_member";
export const MEMBER_SESSION_MS = 30 * 24 * 60 * 60 * 1000;

export type MemberIdentity = { id: string; phone: string };

export function digestSessionToken(token: string): string {
  return createHash("sha256").update(token).digest("hex");
}

export function readMemberCookie(req: Request): string | undefined {
  const header = req.headers.cookie;
  if (!header) return undefined;
  for (const part of header.split(";")) {
    const [key, ...value] = part.trim().split("=");
    if (key === MEMBER_COOKIE) {
      try {
        return decodeURIComponent(value.join("="));
      } catch {
        return undefined;
      }
    }
  }
  return undefined;
}

export function writeMemberCookie(res: Response, token: string, maxAgeSeconds: number): void {
  const flags = ["Path=/api", "HttpOnly", "SameSite=Strict", `Max-Age=${maxAgeSeconds}`];
  if (process.env.NODE_ENV === "production") flags.push("Secure");
  res.setHeader("Set-Cookie", `${MEMBER_COOKIE}=${encodeURIComponent(token)}; ${flags.join("; ")}`);
}

export async function createMemberSession(userId: string): Promise<{ token: string; expiresAt: Date }> {
  const token = randomBytes(32).toString("base64url");
  const expiresAt = new Date(Date.now() + MEMBER_SESSION_MS);
  await db.insert(memberSessions).values({
    userId,
    tokenHash: digestSessionToken(token),
    expiresAt,
  });
  return { token, expiresAt };
}

export async function getMemberIdentity(req: Request): Promise<MemberIdentity | null> {
  const token = readMemberCookie(req);
  if (!token || token.length < 32) return null;
  const rows = await db.select({ id: users.id, phone: users.phone })
    .from(memberSessions)
    .innerJoin(users, eq(memberSessions.userId, users.id))
    .where(and(
      eq(memberSessions.tokenHash, digestSessionToken(token)),
      isNull(memberSessions.revokedAt),
      gt(memberSessions.expiresAt, new Date()),
      eq(users.status, "active"),
    ))
    .limit(1);
  return rows[0] ?? null;
}
