import { Router, type IRouter } from "express";
import healthRouter from "./health";
import adminRouter from "./admin";
import catalogRouter from "./catalog";
import authRouter from "./auth";
import memberRouter from "./members";
import storageRouter from "./storage";

const router: IRouter = Router();

router.use(healthRouter);
router.use(catalogRouter);
router.use(authRouter);
router.use(memberRouter);
router.use(storageRouter);
router.use(adminRouter);

export default router;
