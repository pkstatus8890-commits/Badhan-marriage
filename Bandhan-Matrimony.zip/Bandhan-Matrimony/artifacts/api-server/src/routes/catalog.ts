import { Router, type IRouter } from "express";
import { and, asc, ilike, eq } from "drizzle-orm";
import { db, casteCategories, castesCommunities, courseCategories, courses, subscriptionPlans } from "@workspace/db";
import { ListPublicCommunitiesQueryParams, ListPublicCommunitiesResponse, ListPublishedCoursesResponse, ListPublicPlansResponse } from "@workspace/api-zod";
import { ensureBandhanCatalog } from "../lib/bandhan-catalog";

const router: IRouter = Router();

router.get("/communities", async (req, res): Promise<void> => {
  const parsed = ListPublicCommunitiesQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  await ensureBandhanCatalog();
  const q = parsed.data.q?.trim();
  const query = db.select({ id: castesCommunities.id, name: castesCommunities.name, category: casteCategories.name })
    .from(castesCommunities)
    .leftJoin(casteCategories, eq(castesCommunities.categoryId, casteCategories.id))
    .where(q
      ? and(eq(castesCommunities.active, true), ilike(castesCommunities.name, `%${q}%`))
      : eq(castesCommunities.active, true))
    .orderBy(asc(castesCommunities.name))
    .limit(parsed.data.limit ?? 100);
  const records = await query;
  res.json(ListPublicCommunitiesResponse.parse(records));
});

router.get("/courses", async (_req, res): Promise<void> => {
  await ensureBandhanCatalog();
  const records = await db.select({
    id: courses.id, title: courses.title, shortDescription: courses.shortDescription,
    description: courses.description, category: courseCategories.name, duration: courses.duration,
    price: courses.price, isFree: courses.isFree, thumbnailPath: courses.thumbnailPath,
    content: courses.content, externalLink: courses.externalLink,
  }).from(courses)
    .leftJoin(courseCategories, eq(courses.categoryId, courseCategories.id))
    .where(eq(courses.status, "published"))
    .orderBy(asc(courses.title));
  res.json(ListPublishedCoursesResponse.parse(records.map((course) => ({ ...course, price: Number(course.price) }))));
});

router.get("/plans", async (_req, res): Promise<void> => {
  await ensureBandhanCatalog();
  const records = await db.select({
    id: subscriptionPlans.id, name: subscriptionPlans.name,
    monthlyPrice: subscriptionPlans.monthlyPrice, currency: subscriptionPlans.currency,
    durationDays: subscriptionPlans.durationDays, features: subscriptionPlans.features,
    messageLimit: subscriptionPlans.messageLimit, unlimitedMessaging: subscriptionPlans.unlimitedMessaging,
    advancedSearch: subscriptionPlans.advancedSearch, priorityListing: subscriptionPlans.priorityListing,
  }).from(subscriptionPlans).where(eq(subscriptionPlans.active, true)).orderBy(asc(subscriptionPlans.monthlyPrice));
  res.json(ListPublicPlansResponse.parse(records.map((plan) => ({ ...plan, monthlyPrice: Number(plan.monthlyPrice) }))));
});

export default router;
