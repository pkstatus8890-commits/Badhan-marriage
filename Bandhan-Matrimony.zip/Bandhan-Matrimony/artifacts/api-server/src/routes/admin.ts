import { createHash, randomBytes, scryptSync, timingSafeEqual } from "node:crypto";
import { Router, type Request, type Response, type IRouter } from "express";
import { and, asc, count, desc, eq, gt, gte, ilike, inArray, isNull, lt, ne, or, sql } from "drizzle-orm";
import {
  AdminLoginBody, AdminLoginResponse, AdminLogoutResponse, GetAdminDashboardResponse,
  GetAdminDataResponse, GetAdminSessionResponse, RunAdminActionBody, RunAdminActionResponse,
} from "@workspace/api-zod";
import {
  adminActivityLogs, adminSessions, adminUsers, appSettings, casteCategories, castesCommunities,
  conversations, courseCategories, courseEnrollments, courses, db, matrimonialRequests, messages,
  payments, profilePhotos, profiles, reports, searchableFields, subscriptionPlans, subscriptions,
  userBlocks, users,
} from "@workspace/db";
import { ensureBandhanCatalog } from "../lib/bandhan-catalog";

const router: IRouter = Router();
const SESSION_COOKIE = "bandhan_admin";
const SESSION_MS = 8 * 60 * 60 * 1000;
const loginWindows = new Map<string, { attempts: number; resetAt: number }>();
type AdminIdentity = { id: string; email: string; role: "admin" | "super_admin" };

function getCookie(req: Request, name: string): string | undefined {
  const cookieHeader = req.headers.cookie;
  if (!cookieHeader) return undefined;
  for (const part of cookieHeader.split(";")) {
    const [key, ...value] = part.trim().split("=");
    if (key === name) return decodeURIComponent(value.join("="));
  }
  return undefined;
}

function setSessionCookie(res: Response, token: string, maxAge: number): void {
  const flags = ["Path=/api", "HttpOnly", "SameSite=Strict", `Max-Age=${maxAge}`];
  if (process.env.NODE_ENV === "production") flags.push("Secure");
  res.setHeader("Set-Cookie", `${SESSION_COOKIE}=${encodeURIComponent(token)}; ${flags.join("; ")}`);
}

function tokenDigest(token: string): string {
  return createHash("sha256").update(token).digest("hex");
}

function configuredPasswordHash(email: string, password: string): string {
  const salt = `${email}:${process.env.SESSION_SECRET ?? ""}`;
  return scryptSync(password, salt, 64).toString("hex");
}

export async function getAdminIdentity(req: Request): Promise<AdminIdentity | null> {
  const token = getCookie(req, SESSION_COOKIE);
  if (!token || token.length < 32) return null;
  const now = new Date();
  const rows = await db.select({
    id: adminUsers.id, email: adminUsers.email, role: adminUsers.role,
  }).from(adminSessions)
    .innerJoin(adminUsers, eq(adminSessions.adminId, adminUsers.id))
    .where(and(
      eq(adminSessions.tokenHash, tokenDigest(token)),
      isNull(adminSessions.revokedAt),
      gt(adminSessions.expiresAt, now),
      eq(adminUsers.status, "active"),
    )).limit(1);
  const user = rows[0];
  if (!user || (user.role !== "admin" && user.role !== "super_admin")) return null;
  return { id: user.id, email: user.email, role: user.role };
}

async function audit(admin: AdminIdentity, action: string, targetType: string, targetId?: string, details: Record<string, unknown> = {}): Promise<void> {
  await db.insert(adminActivityLogs).values({ adminId: admin.id, action, targetType, targetId: targetId ?? null, details });
}

function requiredString(payload: Record<string, unknown>, key: string, max = 500): string {
  const value = payload[key];
  if (typeof value !== "string" || !value.trim() || value.length > max) throw new Error(`Invalid ${key}`);
  return value.trim();
}

function optionalString(payload: Record<string, unknown>, key: string, max = 4000): string | null {
  const value = payload[key];
  if (value == null || value === "") return null;
  if (typeof value !== "string" || value.length > max) throw new Error(`Invalid ${key}`);
  return value.trim();
}

function boolValue(payload: Record<string, unknown>, key: string, fallback = false): boolean {
  const value = payload[key];
  if (value == null) return fallback;
  if (typeof value !== "boolean") throw new Error(`Invalid ${key}`);
  return value;
}

function intValue(payload: Record<string, unknown>, key: string, fallback: number, min: number, max: number): number {
  const value = payload[key];
  if (value == null) return fallback;
  if (!Number.isInteger(value) || Number(value) < min || Number(value) > max) throw new Error(`Invalid ${key}`);
  return Number(value);
}

async function runAction(admin: AdminIdentity, action: string, payload: Record<string, unknown>): Promise<string | null> {
  let targetId = typeof payload.id === "string" ? payload.id : null;
  switch (action) {
    case "user-status": {
      const status = requiredString(payload, "status", 32);
      if (!["active", "suspended", "blocked"].includes(status)) throw new Error("Invalid account status");
      const [updated] = await db.update(users).set({ status }).where(eq(users.id, requiredString(payload, "id", 64))).returning({ id: users.id });
      if (!updated) throw new Error("User not found");
      await db.update(profiles).set({ activityStatus: status }).where(eq(profiles.userId, updated.id));
      targetId = updated.id;
      break;
    }
    case "user-delete": {
      const [deleted] = await db.delete(users).where(eq(users.id, requiredString(payload, "id", 64))).returning({ id: users.id });
      if (!deleted) throw new Error("User not found");
      targetId = deleted.id;
      break;
    }
    case "profile-status": {
      const status = requiredString(payload, "status", 32);
      if (!["pending", "approved", "rejected", "suspended"].includes(status)) throw new Error("Invalid profile status");
      const reason = status === "rejected" ? requiredString(payload, "reason", 1000) : null;
      const [updated] = await db.update(profiles).set({
        approvalStatus: status,
        rejectionReason: reason,
        approvedAt: status === "approved" ? new Date() : null,
        activityStatus: status === "suspended" ? "suspended" : "active",
      }).where(eq(profiles.id, requiredString(payload, "id", 64))).returning({ id: profiles.id });
      if (!updated) throw new Error("Profile not found");
      targetId = updated.id;
      break;
    }
    case "photo-status": {
      const status = requiredString(payload, "status", 24);
      if (!["pending", "approved", "rejected"].includes(status)) throw new Error("Invalid photo moderation status");
      const [updated] = await db.update(profilePhotos).set({ moderationStatus: status })
        .where(eq(profilePhotos.id, requiredString(payload, "id", 64)))
        .returning({ id: profilePhotos.id });
      if (!updated) throw new Error("Profile photo not found");
      targetId = updated.id;
      break;
    }
    case "community-save": {
      const name = requiredString(payload, "name", 120);
      const categoryId = optionalString(payload, "categoryId", 64);
      const stateCoverage = Array.isArray(payload.stateCoverage)
        ? payload.stateCoverage.filter((item): item is string => typeof item === "string").slice(0, 40)
        : [];
      const id = optionalString(payload, "id", 64);
      if (id) {
        const [updated] = await db.update(castesCommunities).set({ name, categoryId, stateCoverage, active: boolValue(payload, "active", true), updatedAt: new Date() }).where(eq(castesCommunities.id, id)).returning({ id: castesCommunities.id });
        if (!updated) throw new Error("Community not found");
        targetId = updated.id;
      } else {
        const [created] = await db.insert(castesCommunities).values({ name, categoryId, stateCoverage }).returning({ id: castesCommunities.id });
        targetId = created.id;
      }
      break;
    }
    case "community-deactivate": {
      const [updated] = await db.update(castesCommunities).set({ active: false }).where(eq(castesCommunities.id, requiredString(payload, "id", 64))).returning({ id: castesCommunities.id });
      if (!updated) throw new Error("Community not found");
      targetId = updated.id;
      break;
    }
    case "community-import": {
      if (!Array.isArray(payload.names) || payload.names.length > 1000) throw new Error("Provide at most 1000 community names");
      const names = [...new Set(payload.names.filter((name): name is string => typeof name === "string").map((name) => name.trim()).filter((name) => name.length > 0 && name.length <= 120))];
      if (names.length) await db.insert(castesCommunities).values(names.map((name) => ({ name, categoryId: optionalString(payload, "categoryId", 64) }))).onConflictDoNothing();
      targetId = null;
      break;
    }
    case "community-category-save": {
      const name = requiredString(payload, "name", 80);
      const id = optionalString(payload, "id", 64);
      if (id) {
        const [updated] = await db.update(casteCategories).set({ name, active: boolValue(payload, "active", true), sortOrder: intValue(payload, "sortOrder", 0, 0, 10000) }).where(eq(casteCategories.id, id)).returning({ id: casteCategories.id });
        if (!updated) throw new Error("Community category not found");
        targetId = updated.id;
      } else {
        const [created] = await db.insert(casteCategories).values({ name, sortOrder: intValue(payload, "sortOrder", 0, 0, 10000) }).returning({ id: casteCategories.id });
        targetId = created.id;
      }
      break;
    }
    case "community-category-deactivate": {
      const [updated] = await db.update(casteCategories).set({ active: false }).where(eq(casteCategories.id, requiredString(payload, "id", 64))).returning({ id: casteCategories.id });
      if (!updated) throw new Error("Category not found");
      targetId = updated.id;
      break;
    }
    case "plan-save": {
      const name = requiredString(payload, "name", 120);
      const monthlyPrice = Number(payload.monthlyPrice);
      const durationDays = intValue(payload, "durationDays", 30, 1, 3660);
      const messageLimit = payload.messageLimit === null ? null : intValue(payload, "messageLimit", 5, 0, 100000);
      if (!Number.isFinite(monthlyPrice) || monthlyPrice < 0 || monthlyPrice > 10000000) throw new Error("Invalid monthly price");
      const values = {
        name, monthlyPrice: monthlyPrice.toFixed(2), durationDays,
        features: Array.isArray(payload.features) ? payload.features.filter((item): item is string => typeof item === "string").slice(0, 50) : [],
        messageLimit, unlimitedMessaging: boolValue(payload, "unlimitedMessaging"),
        profileVisibility: optionalString(payload, "profileVisibility", 40) ?? "standard",
        advancedSearch: boolValue(payload, "advancedSearch"), priorityListing: boolValue(payload, "priorityListing"),
        active: boolValue(payload, "active", true), updatedAt: new Date(),
      };
      const id = optionalString(payload, "id", 64);
      if (id) {
        const [updated] = await db.update(subscriptionPlans).set(values).where(eq(subscriptionPlans.id, id)).returning({ id: subscriptionPlans.id });
        if (!updated) throw new Error("Plan not found");
        targetId = updated.id;
      } else {
        const [created] = await db.insert(subscriptionPlans).values(values).returning({ id: subscriptionPlans.id });
        targetId = created.id;
      }
      break;
    }
    case "plan-toggle": {
      const [updated] = await db.update(subscriptionPlans).set({ active: boolValue(payload, "active") }).where(eq(subscriptionPlans.id, requiredString(payload, "id", 64))).returning({ id: subscriptionPlans.id });
      if (!updated) throw new Error("Plan not found");
      targetId = updated.id;
      break;
    }
    case "subscription-status": {
      const status = requiredString(payload, "status", 24);
      if (!["active", "expired", "cancelled"].includes(status)) throw new Error("Invalid subscription status");
      const [updated] = await db.update(subscriptions).set({
        status, cancelledAt: status === "cancelled" ? new Date() : null,
      }).where(eq(subscriptions.id, requiredString(payload, "id", 64))).returning({ id: subscriptions.id });
      if (!updated) throw new Error("Subscription not found");
      targetId = updated.id;
      break;
    }
    case "message-settings": {
      const entries = [
        ["free_message_limit", String(intValue(payload, "freeMessageLimit", 5, 0, 10000))],
        ["premium_message_limit", String(intValue(payload, "premiumMessageLimit", 100, 0, 100000))],
        ["premium_unlimited_messaging", String(boolValue(payload, "premiumUnlimitedMessaging"))],
      ] as const;
      for (const [key, value] of entries) {
        await db.insert(appSettings).values({ key, value, updatedBy: admin.id, updatedAt: new Date() })
          .onConflictDoUpdate({ target: appSettings.key, set: { value, updatedBy: admin.id, updatedAt: new Date() } });
      }
      targetId = "message-rules";
      break;
    }
    case "search-field-toggle": {
      const [updated] = await db.update(searchableFields).set({ enabled: boolValue(payload, "enabled") }).where(eq(searchableFields.key, requiredString(payload, "key", 80))).returning({ key: searchableFields.key });
      if (!updated) throw new Error("Search field not found");
      targetId = updated.key;
      break;
    }
    case "course-category-save": {
      const name = requiredString(payload, "name", 100);
      const id = optionalString(payload, "id", 64);
      if (id) {
        const [updated] = await db.update(courseCategories).set({ name, active: boolValue(payload, "active", true), sortOrder: intValue(payload, "sortOrder", 0, 0, 10000) }).where(eq(courseCategories.id, id)).returning({ id: courseCategories.id });
        if (!updated) throw new Error("Course category not found");
        targetId = updated.id;
      } else {
        const [created] = await db.insert(courseCategories).values({ name, sortOrder: intValue(payload, "sortOrder", 0, 0, 10000) }).returning({ id: courseCategories.id });
        targetId = created.id;
      }
      break;
    }
    case "course-category-deactivate": {
      const [updated] = await db.update(courseCategories).set({ active: false }).where(eq(courseCategories.id, requiredString(payload, "id", 64))).returning({ id: courseCategories.id });
      if (!updated) throw new Error("Course category not found");
      targetId = updated.id;
      break;
    }
    case "course-save": {
      const title = requiredString(payload, "title", 180);
      const price = Number(payload.price ?? 0);
      if (!Number.isFinite(price) || price < 0 || price > 10000000) throw new Error("Invalid course price");
      const status = requiredString(payload, "status", 20);
      if (!["draft", "published", "inactive"].includes(status)) throw new Error("Invalid course status");
      const content = Array.isArray(payload.content)
        ? payload.content.filter((item): item is { title: string; body: string; link?: string } => !!item && typeof item === "object" && typeof (item as any).title === "string" && typeof (item as any).body === "string").slice(0, 100)
        : [];
      const values = {
        title, shortDescription: optionalString(payload, "shortDescription", 500) ?? "",
        description: optionalString(payload, "description", 20000) ?? "",
        categoryId: optionalString(payload, "categoryId", 64),
        thumbnailPath: optionalString(payload, "thumbnailPath", 2000),
        duration: optionalString(payload, "duration", 100) ?? "",
        price: price.toFixed(2), isFree: boolValue(payload, "isFree", price === 0),
        status, content, externalLink: optionalString(payload, "externalLink", 2000), updatedAt: new Date(),
      };
      const id = optionalString(payload, "id", 64);
      if (id) {
        const [updated] = await db.update(courses).set(values).where(eq(courses.id, id)).returning({ id: courses.id });
        if (!updated) throw new Error("Course not found");
        targetId = updated.id;
      } else {
        const [created] = await db.insert(courses).values(values).returning({ id: courses.id });
        targetId = created.id;
      }
      break;
    }
    case "course-deactivate": {
      const [updated] = await db.update(courses).set({ status: "inactive" }).where(eq(courses.id, requiredString(payload, "id", 64))).returning({ id: courses.id });
      if (!updated) throw new Error("Course not found");
      targetId = updated.id;
      break;
    }
    case "course-enrollment-status": {
      const status = requiredString(payload, "status", 24);
      if (!["active", "cancelled", "completed"].includes(status)) throw new Error("Invalid enrollment status");
      const [updated] = await db.update(courseEnrollments).set({ status, completedAt: status === "completed" ? new Date() : null }).where(eq(courseEnrollments.id, requiredString(payload, "id", 64))).returning({ id: courseEnrollments.id });
      if (!updated) throw new Error("Enrollment not found");
      targetId = updated.id;
      break;
    }
    case "report-action": {
      const reportId = requiredString(payload, "id", 64);
      const choice = requiredString(payload, "choice", 24);
      const [report] = await db.select({ id: reports.id, userId: reports.reportedUserId }).from(reports).where(eq(reports.id, reportId)).limit(1);
      if (!report) throw new Error("Report not found");
      if (choice === "suspend" || choice === "block") {
        const status = choice === "suspend" ? "suspended" : "blocked";
        await db.update(users).set({ status }).where(eq(users.id, report.userId));
        await db.update(profiles).set({ activityStatus: status }).where(eq(profiles.userId, report.userId));
      } else if (!["review", "warn", "resolve"].includes(choice)) {
        throw new Error("Invalid report action");
      }
      const [updated] = await db.update(reports).set({
        status: choice === "review" ? "reviewing" : "resolved",
        resolution: choice,
        resolvedAt: choice === "review" ? null : new Date(),
      }).where(eq(reports.id, reportId)).returning({ id: reports.id });
      targetId = updated.id;
      break;
    }
    default:
      throw new Error("Unknown administrative action");
  }
  await audit(admin, action, action.split("-")[0] ?? "record", targetId ?? undefined, {});
  return targetId;
}

router.post("/admin/login", async (req, res): Promise<void> => {
  const parsed = AdminLoginBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const ip = req.ip ?? "unknown";
  const window = loginWindows.get(ip);
  if (window && window.resetAt > Date.now() && window.attempts >= 5) {
    res.status(429).json({ error: "Too many attempts. Try again later." });
    return;
  }
  const configuredEmail = process.env.BANDHAN_ADMIN_EMAIL?.trim().toLowerCase();
  const configuredPassword = process.env.BANDHAN_ADMIN_PASSWORD;
  const sessionSecret = process.env.SESSION_SECRET;
  if (!configuredEmail || !configuredPassword || !sessionSecret) {
    res.status(503).json({ error: "Admin credentials are not configured in workspace secrets." });
    return;
  }
  const inputEmail = parsed.data.email.trim().toLowerCase();
  const inputPassword = Buffer.from(parsed.data.password);
  const expectedPassword = Buffer.from(configuredPassword);
  const passwordMatches = inputPassword.length === expectedPassword.length && timingSafeEqual(inputPassword, expectedPassword);
  if (inputEmail !== configuredEmail || !passwordMatches) {
    const attempts = window && window.resetAt > Date.now() ? window.attempts + 1 : 1;
    loginWindows.set(ip, { attempts, resetAt: Date.now() + 15 * 60 * 1000 });
    res.status(401).json({ error: "Invalid administrator credentials." });
    return;
  }
  loginWindows.delete(ip);
  const passwordHash = configuredPasswordHash(inputEmail, configuredPassword);
  const [admin] = await db.insert(adminUsers).values({ email: inputEmail, passwordHash, role: "super_admin", status: "active" })
    .onConflictDoUpdate({ target: adminUsers.email, set: { passwordHash, role: "super_admin", status: "active" } })
    .returning({ id: adminUsers.id, email: adminUsers.email, role: adminUsers.role });
  const token = randomBytes(32).toString("base64url");
  const expiresAt = new Date(Date.now() + SESSION_MS);
  await db.insert(adminSessions).values({ adminId: admin.id, tokenHash: tokenDigest(token), expiresAt });
  await db.update(adminUsers).set({ lastLoginAt: new Date() }).where(eq(adminUsers.id, admin.id));
  const identity = AdminLoginResponse.parse({ id: admin.id, email: admin.email, role: admin.role });
  setSessionCookie(res, token, Math.floor(SESSION_MS / 1000));
  res.json(identity);
});

router.get("/admin/session", async (req, res): Promise<void> => {
  const admin = await getAdminIdentity(req);
  if (!admin) {
    res.status(401).json({ error: "Administrator access required." });
    return;
  }
  res.json(GetAdminSessionResponse.parse(admin));
});

router.post("/admin/logout", async (req, res): Promise<void> => {
  const token = getCookie(req, SESSION_COOKIE);
  if (token) {
    await db.update(adminSessions).set({ revokedAt: new Date() }).where(and(eq(adminSessions.tokenHash, tokenDigest(token)), isNull(adminSessions.revokedAt)));
  }
  setSessionCookie(res, "", 0);
  res.json(AdminLogoutResponse.parse({ ok: true }));
});

router.get("/admin/dashboard", async (req, res): Promise<void> => {
  const admin = await getAdminIdentity(req);
  if (!admin) {
    res.status(401).json({ error: "Administrator access required." });
    return;
  }
  await ensureBandhanCatalog();
  const now = new Date();
  const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);
  const [
    totalUsers, maleProfiles, femaleProfiles, activeProfiles, pendingApprovals,
    totalRequests, acceptedRequests, activeChats, premiumSubscribers,
    activeSubscriptions, expiredSubscriptions, cancelledSubscriptions,
    revenue, renewalsDue, popular, reportedUsers, blockedUsers,
    totalCourses, publishedCourses, draftCourses, courseEnrollmentCount,
  ] = await Promise.all([
    db.select({ value: count() }).from(users),
    db.select({ value: count() }).from(profiles).where(eq(profiles.gender, "Man")),
    db.select({ value: count() }).from(profiles).where(eq(profiles.gender, "Woman")),
    db.select({ value: count() }).from(profiles).where(and(eq(profiles.approvalStatus, "approved"), eq(profiles.activityStatus, "active"))),
    db.select({ value: count() }).from(profiles).where(eq(profiles.approvalStatus, "pending")),
    db.select({ value: count() }).from(matrimonialRequests),
    db.select({ value: count() }).from(matrimonialRequests).where(eq(matrimonialRequests.status, "accepted")),
    db.select({ value: count() }).from(conversations).where(eq(conversations.status, "active")),
    db.select({ value: sql<number>`count(distinct ${subscriptions.userId})` }).from(subscriptions)
      .innerJoin(subscriptionPlans, eq(subscriptions.planId, subscriptionPlans.id))
      .where(and(eq(subscriptions.status, "active"), gt(subscriptions.expiresAt, now), gt(subscriptionPlans.monthlyPrice, "0"))),
    db.select({ value: count() }).from(subscriptions).where(and(eq(subscriptions.status, "active"), gt(subscriptions.expiresAt, now))),
    db.select({ value: count() }).from(subscriptions).where(or(eq(subscriptions.status, "expired"), and(ne(subscriptions.status, "cancelled"), lt(subscriptions.expiresAt, now)))),
    db.select({ value: count() }).from(subscriptions).where(eq(subscriptions.status, "cancelled")),
    db.select({ value: sql<string>`coalesce(sum(${payments.amount}), 0)` }).from(payments).where(and(inArray(payments.status, ["paid", "succeeded"]), gte(payments.paidAt, monthStart))),
    db.select({ value: count() }).from(subscriptions).where(and(eq(subscriptions.status, "active"), gte(subscriptions.expiresAt, now), lt(subscriptions.expiresAt, new Date(now.getTime() + 30 * 86400000)))),
    db.select({ name: subscriptionPlans.name, value: count() }).from(subscriptions).innerJoin(subscriptionPlans, eq(subscriptions.planId, subscriptionPlans.id)).groupBy(subscriptionPlans.name).orderBy(desc(count())).limit(1),
    db.select({ value: sql<number>`count(distinct ${reports.reportedUserId})` }).from(reports).where(inArray(reports.status, ["open", "reviewing"])),
    db.select({ value: sql<number>`count(distinct ${users.id})` }).from(users).where(eq(users.status, "blocked")),
    db.select({ value: count() }).from(courses),
    db.select({ value: count() }).from(courses).where(eq(courses.status, "published")),
    db.select({ value: count() }).from(courses).where(eq(courses.status, "draft")),
    db.select({ value: count() }).from(courseEnrollments),
  ]);
  res.json(GetAdminDashboardResponse.parse({
    totalUsers: totalUsers[0]?.value ?? 0, maleProfiles: maleProfiles[0]?.value ?? 0,
    femaleProfiles: femaleProfiles[0]?.value ?? 0, activeProfiles: activeProfiles[0]?.value ?? 0,
    pendingApprovals: pendingApprovals[0]?.value ?? 0, totalRequests: totalRequests[0]?.value ?? 0,
    acceptedRequests: acceptedRequests[0]?.value ?? 0, activeChats: activeChats[0]?.value ?? 0,
    premiumSubscribers: premiumSubscribers[0]?.value ?? 0, activeSubscriptions: activeSubscriptions[0]?.value ?? 0,
    expiredSubscriptions: expiredSubscriptions[0]?.value ?? 0, cancelledSubscriptions: cancelledSubscriptions[0]?.value ?? 0,
    monthlyRevenue: Number(revenue[0]?.value ?? 0), renewalsDue: renewalsDue[0]?.value ?? 0,
    popularPlan: popular[0]?.name ?? "—", reportedUsers: reportedUsers[0]?.value ?? 0,
    blockedUsers: blockedUsers[0]?.value ?? 0, totalCourses: totalCourses[0]?.value ?? 0,
    publishedCourses: publishedCourses[0]?.value ?? 0, draftCourses: draftCourses[0]?.value ?? 0,
    courseEnrollments: courseEnrollmentCount[0]?.value ?? 0,
  }));
});

router.get("/admin/data", async (req, res): Promise<void> => {
  const admin = await getAdminIdentity(req);
  if (!admin) {
    res.status(401).json({ error: "Administrator access required." });
    return;
  }
  await ensureBandhanCatalog();
  const [
    userRows, photoRows, subscriptionRows, requestRows, conversationRows, messageCounts,
    reportRows, communityRows, categoryRows, plans, paymentsRows, courseRows,
    courseCategoryRows, enrollmentRows, fields, settingsRows, activityRows,
  ] = await Promise.all([
    db.select({
      id: users.id, phone: users.phone, email: users.email, status: users.status, createdAt: users.createdAt, lastLoginAt: users.lastLoginAt,
      profileId: profiles.id, name: profiles.name, dateOfBirth: profiles.dateOfBirth, gender: profiles.gender,
      city: profiles.city, state: profiles.state, communityId: profiles.communityId, community: castesCommunities.name,
      district: profiles.district, religion: profiles.religion, subCommunity: profiles.subCommunity,
      education: profiles.education, profession: profiles.profession, maritalStatus: profiles.maritalStatus, gotra: profiles.gotra,
      height: profiles.height, family: profiles.family, about: profiles.about, partnerPreference: profiles.partnerPreference,
      approvalStatus: profiles.approvalStatus, rejectionReason: profiles.rejectionReason, activityStatus: profiles.activityStatus,
      profileCreatedAt: profiles.createdAt,
    }).from(users).leftJoin(profiles, eq(profiles.userId, users.id))
      .leftJoin(castesCommunities, eq(profiles.communityId, castesCommunities.id))
      .orderBy(desc(users.createdAt)).limit(1000),
    db.select({ profileId: profilePhotos.profileId, id: profilePhotos.id, objectPath: profilePhotos.objectPath, isPrimary: profilePhotos.isPrimary, status: profilePhotos.moderationStatus, createdAt: profilePhotos.createdAt }).from(profilePhotos).orderBy(desc(profilePhotos.createdAt)).limit(2000),
    db.select({
      id: subscriptions.id, userId: subscriptions.userId, planId: subscriptions.planId, status: subscriptions.status,
      startsAt: subscriptions.startsAt, expiresAt: subscriptions.expiresAt, cancelledAt: subscriptions.cancelledAt,
      planName: subscriptionPlans.name, amount: subscriptionPlans.monthlyPrice,
    }).from(subscriptions).innerJoin(subscriptionPlans, eq(subscriptions.planId, subscriptionPlans.id)).orderBy(desc(subscriptions.createdAt)).limit(1000),
    db.select({ id: matrimonialRequests.id, fromProfileId: matrimonialRequests.fromProfileId, toProfileId: matrimonialRequests.toProfileId, status: matrimonialRequests.status, createdAt: matrimonialRequests.createdAt, updatedAt: matrimonialRequests.updatedAt }).from(matrimonialRequests).orderBy(desc(matrimonialRequests.createdAt)).limit(1000),
    db.select({ id: conversations.id, requestId: conversations.requestId, profileAId: conversations.profileAId, profileBId: conversations.profileBId, status: conversations.status, createdAt: conversations.createdAt }).from(conversations).orderBy(desc(conversations.createdAt)).limit(1000),
    db.select({ conversationId: messages.conversationId, value: count() }).from(messages).groupBy(messages.conversationId),
    db.select({ id: reports.id, reporterUserId: reports.reporterUserId, reportedUserId: reports.reportedUserId, reason: reports.reason, description: reports.description, status: reports.status, resolution: reports.resolution, createdAt: reports.createdAt, resolvedAt: reports.resolvedAt }).from(reports).orderBy(desc(reports.createdAt)).limit(1000),
    db.select({ id: castesCommunities.id, name: castesCommunities.name, categoryId: castesCommunities.categoryId, category: casteCategories.name, stateCoverage: castesCommunities.stateCoverage, active: castesCommunities.active, createdAt: castesCommunities.createdAt }).from(castesCommunities).leftJoin(casteCategories, eq(castesCommunities.categoryId, casteCategories.id)).orderBy(asc(castesCommunities.name)),
    db.select().from(casteCategories).orderBy(asc(casteCategories.sortOrder)),
    db.select().from(subscriptionPlans).orderBy(asc(subscriptionPlans.monthlyPrice)),
    db.select({ id: payments.id, subscriptionId: payments.subscriptionId, userId: payments.userId, amount: payments.amount, currency: payments.currency, status: payments.status, provider: payments.provider, providerPaymentRef: payments.providerPaymentRef, paidAt: payments.paidAt, createdAt: payments.createdAt }).from(payments).orderBy(desc(payments.createdAt)).limit(1000),
    db.select({ id: courses.id, title: courses.title, shortDescription: courses.shortDescription, description: courses.description, categoryId: courses.categoryId, category: courseCategories.name, thumbnailPath: courses.thumbnailPath, duration: courses.duration, price: courses.price, isFree: courses.isFree, status: courses.status, content: courses.content, externalLink: courses.externalLink, createdAt: courses.createdAt, updatedAt: courses.updatedAt }).from(courses).leftJoin(courseCategories, eq(courses.categoryId, courseCategories.id)).orderBy(desc(courses.createdAt)),
    db.select().from(courseCategories).orderBy(asc(courseCategories.sortOrder)),
    db.select({ id: courseEnrollments.id, courseId: courseEnrollments.courseId, userId: courseEnrollments.userId, status: courseEnrollments.status, enrolledAt: courseEnrollments.enrolledAt, completedAt: courseEnrollments.completedAt }).from(courseEnrollments).orderBy(desc(courseEnrollments.enrolledAt)).limit(1000),
    db.select().from(searchableFields).orderBy(asc(searchableFields.sortOrder)),
    db.select({ key: appSettings.key, value: appSettings.value }).from(appSettings),
    db.select({ id: adminActivityLogs.id, adminId: adminActivityLogs.adminId, email: adminUsers.email, action: adminActivityLogs.action, targetType: adminActivityLogs.targetType, targetId: adminActivityLogs.targetId, details: adminActivityLogs.details, createdAt: adminActivityLogs.createdAt }).from(adminActivityLogs).innerJoin(adminUsers, eq(adminActivityLogs.adminId, adminUsers.id)).orderBy(desc(adminActivityLogs.createdAt)).limit(200),
  ]);
  const photosByProfile = new Map<string, typeof photoRows>();
  for (const photo of photoRows) photosByProfile.set(photo.profileId, [...(photosByProfile.get(photo.profileId) ?? []), photo]);
  const subscriptionsByUser = new Map<string, (typeof subscriptionRows)[number]>();
  for (const sub of subscriptionRows) if (!subscriptionsByUser.has(sub.userId)) subscriptionsByUser.set(sub.userId, sub);
  const userNames = new Map(userRows.map((user) => [user.id, user.name ?? user.email ?? user.phone]));
  const profileNames = new Map(userRows.filter((user) => user.profileId).map((user) => [user.profileId!, user.name ?? user.phone]));
  const reportsForAdmin = reportRows.map((report) => ({
    ...report, reporter: userNames.get(report.reporterUserId) ?? report.reporterUserId,
    reportedUser: userNames.get(report.reportedUserId) ?? report.reportedUserId,
  }));
  const conversationsForAdmin = conversationsFromRows(conversationRows, messageCounts, profileNames);
  const paymentsForAdmin = paymentsRows.map((payment) => ({ ...payment, user: userNames.get(payment.userId) ?? payment.userId, amount: Number(payment.amount) }));
  const data = {
    users: userRows.map((user) => {
      const {
        id: userId, phone, email, status, createdAt, lastLoginAt,
        profileId, profileCreatedAt, communityId, name, dateOfBirth, gender,
        city, district, state, religion, community, subCommunity, education, profession, maritalStatus, gotra,
        height, family, about, partnerPreference, approvalStatus, rejectionReason,
        activityStatus,
      } = user;
      const photos = profileId ? (photosByProfile.get(profileId) ?? []) : [];
      const profile = profileId ? {
        id: profileId, createdAt: profileCreatedAt, communityId, name, dateOfBirth, gender,
        city, district, state, religion, community, subCommunity, education, profession, maritalStatus, gotra, height,
        family, about, partnerPreference, approvalStatus, rejectionReason, activityStatus, photos,
      } : undefined;
      const subscription = subscriptionsByUser.get(userId);
      return {
        id: userId, phone, email, status, createdAt, lastLoginAt, profile,
        subscription: subscription ? { ...subscription, amount: Number(subscription.amount) } : undefined,
      };
    }),
    requests: requestRows.map((request) => ({
      ...request, from: profileNames.get(request.fromProfileId) ?? request.fromProfileId,
      to: profileNames.get(request.toProfileId) ?? request.toProfileId,
    })),
    conversations: conversationsForAdmin,
    reports: reportsForAdmin,
    communities: communityRows,
    communityCategories: categoryRows,
    plans: plans.map((plan) => ({ ...plan, monthlyPrice: Number(plan.monthlyPrice) })),
    subscriptions: subscriptionRows.map((sub) => ({ ...sub, amount: Number(sub.amount), member: userNames.get(sub.userId) ?? sub.userId })),
    payments: paymentsForAdmin,
    courses: courseRows.map((course) => ({ ...course, price: Number(course.price) })),
    courseCategories: courseCategoryRows,
    courseEnrollments: enrollmentRows.map((entry) => ({ ...entry, course: courseRows.find((course) => course.id === entry.courseId)?.title ?? entry.courseId, member: userNames.get(entry.userId) ?? entry.userId })),
    searchFields: fields,
    settings: Object.fromEntries(settingsRows.map((setting) => [setting.key, setting.value])),
    messageSettings: {
      freeMessageLimit: Number(settingsRows.find((setting) => setting.key === "free_message_limit")?.value ?? 5),
      premiumMessageLimit: Number(settingsRows.find((setting) => setting.key === "premium_message_limit")?.value ?? 100),
      premiumUnlimitedMessaging: settingsRows.find((setting) => setting.key === "premium_unlimited_messaging")?.value === "true",
    },
    activity: activityRows,
  };
  res.json(GetAdminDataResponse.parse(data));
});

function conversationsFromRows(
  rows: Array<{ id: string; requestId: string; profileAId: string; profileBId: string; status: string; createdAt: Date }>,
  messageCounts: Array<{ conversationId: string; value: number }>,
  names: Map<string, string>,
) {
  const counts = new Map(messageCounts.map((entry) => [entry.conversationId, entry.value]));
  return rows.map((conversation) => ({
    ...conversation,
    participantA: names.get(conversation.profileAId) ?? conversation.profileAId,
    participantB: names.get(conversation.profileBId) ?? conversation.profileBId,
    messageCount: counts.get(conversation.id) ?? 0,
  }));
}

router.post("/admin/actions", async (req, res): Promise<void> => {
  const admin = await getAdminIdentity(req);
  if (!admin) {
    res.status(401).json({ error: "Administrator access required." });
    return;
  }
  const parsed = RunAdminActionBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  try {
    const id = await runAction(admin, parsed.data.action, parsed.data.payload as Record<string, unknown>);
    res.json(RunAdminActionResponse.parse({ ok: true, id }));
  } catch (error) {
    req.log.warn({ action: parsed.data.action, error: error instanceof Error ? error.message : "unknown" }, "Administrative action rejected");
    res.status(400).json({ error: error instanceof Error ? error.message : "Action failed." });
  }
});

export default router;
