import { createHmac } from "node:crypto";
import { Router, type IRouter } from "express";
import { and, count, eq, gt, isNull, lt } from "drizzle-orm";
import {
  GetMemberSessionResponse, LogoutMemberResponse, RequestMemberOtpBody,
  RequestMemberOtpResponse, VerifyMemberOtpBody, VerifyMemberOtpResponse,
} from "@workspace/api-zod";
import { db, memberSessions, otpSendAttempts, profiles, users } from "@workspace/db";
import {
  createMemberSession, digestSessionToken, getMemberIdentity, MEMBER_SESSION_MS,
  readMemberCookie, writeMemberCookie,
} from "../lib/member-auth";

const router: IRouter = Router();

function normalizeIndianPhone(input: string): string | null {
  const compact = input.trim().replace(/[()\s.-]/g, "");
  const digits = compact.replace(/^\+/, "");
  const national = digits.startsWith("91") && digits.length === 12 ? digits.slice(2) : digits;
  if (!/^[6-9][0-9]{9}$/.test(national)) return null;
  return `+91${national}`;
}

function hmac(value: string): string {
  const secret = process.env.SESSION_SECRET;
  if (!secret) throw new Error("SESSION_SECRET is not configured");
  return createHmac("sha256", secret).update(value).digest("hex");
}

function twilioConfiguration() {
  const accountSid = process.env.TWILIO_ACCOUNT_SID;
  const authToken = process.env.TWILIO_AUTH_TOKEN;
  const verifyServiceSid = process.env.TWILIO_VERIFY_SERVICE_SID;
  return accountSid && authToken && verifyServiceSid ? { accountSid, authToken, verifyServiceSid } : null;
}

async function twilioVerifyRequest(path: "Verifications" | "VerificationChecks", params: Record<string, string>) {
  const config = twilioConfiguration();
  if (!config) return { configured: false as const };
  const credentials = Buffer.from(`${config.accountSid}:${config.authToken}`).toString("base64");
  const response = await fetch(
    `https://verify.twilio.com/v2/Services/${encodeURIComponent(config.verifyServiceSid)}/${path}`,
    {
      method: "POST",
      headers: {
        Authorization: `Basic ${credentials}`,
        "Content-Type": "application/x-www-form-urlencoded",
      },
      body: new URLSearchParams(params),
    },
  );
  const data = await response.json().catch(() => ({})) as { status?: string };
  return { configured: true as const, ok: response.ok, status: response.status, resultStatus: data.status };
}

router.post("/auth/otp/request", async (req, res): Promise<void> => {
  const parsed = RequestMemberOtpBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Enter a valid Indian mobile number." });
    return;
  }
  const phone = normalizeIndianPhone(parsed.data.phone);
  if (!phone) {
    res.status(400).json({ error: "Enter a valid 10-digit Indian mobile number." });
    return;
  }
  if (!process.env.SESSION_SECRET) {
    res.status(503).json({ error: "Secure sign-in is not configured." });
    return;
  }
  if (!twilioConfiguration()) {
    res.status(503).json({ error: "SMS verification is not configured. Contact the administrator." });
    return;
  }

  const phoneHash = hmac(`phone:${phone}`);
  const ipHash = hmac(`ip:${req.ip ?? "unknown"}`);
  const since = new Date(Date.now() - 15 * 60 * 1000);
  await db.delete(otpSendAttempts).where(lt(otpSendAttempts.createdAt, since));
  const [phoneCount, ipCount] = await Promise.all([
    db.select({ total: count() }).from(otpSendAttempts).where(and(eq(otpSendAttempts.phoneHash, phoneHash), gt(otpSendAttempts.createdAt, since))),
    db.select({ total: count() }).from(otpSendAttempts).where(and(eq(otpSendAttempts.ipHash, ipHash), gt(otpSendAttempts.createdAt, since))),
  ]);
  if ((phoneCount[0]?.total ?? 0) >= 3 || (ipCount[0]?.total ?? 0) >= 12) {
    res.status(429).json({ error: "Too many verification requests. Wait 15 minutes and try again." });
    return;
  }
  await db.insert(otpSendAttempts).values({ phoneHash, ipHash });
  try {
    const result = await twilioVerifyRequest("Verifications", { To: phone, Channel: "sms" });
    if (!result.configured) {
      res.status(503).json({ error: "SMS verification is not configured." });
      return;
    }
    if (!result.ok) {
      req.log.warn({ providerStatus: result.status }, "SMS verification request failed");
      res.status(result.status === 429 ? 429 : 503).json({ error: "Unable to send a verification code right now." });
      return;
    }
    res.json(RequestMemberOtpResponse.parse({ sent: true, expiresInSeconds: 600 }));
  } catch (error) {
    req.log.error({ err: error }, "SMS provider request failed");
    res.status(503).json({ error: "Unable to reach the SMS verification provider." });
  }
});

router.post("/auth/otp/verify", async (req, res): Promise<void> => {
  const parsed = VerifyMemberOtpBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Enter your mobile number and verification code." });
    return;
  }
  const phone = normalizeIndianPhone(parsed.data.phone);
  if (!phone) {
    res.status(400).json({ error: "Enter a valid 10-digit Indian mobile number." });
    return;
  }
  if (!twilioConfiguration()) {
    res.status(503).json({ error: "SMS verification is not configured. Contact the administrator." });
    return;
  }
  try {
    const result = await twilioVerifyRequest("VerificationChecks", { To: phone, Code: parsed.data.code });
    if (!result.configured) {
      res.status(503).json({ error: "SMS verification is not configured." });
      return;
    }
    if (!result.ok || result.resultStatus !== "approved") {
      res.status(401).json({ error: "That code is invalid or has expired. Request a new code and try again." });
      return;
    }
    const now = new Date();
    const [user] = await db.insert(users).values({ phone, lastLoginAt: now })
      .onConflictDoUpdate({ target: users.phone, set: { lastLoginAt: now } })
      .returning({ id: users.id, phone: users.phone, status: users.status });
    if (!user || user.status !== "active") {
      res.status(403).json({ error: "This account is not available. Contact support." });
      return;
    }
    const session = await createMemberSession(user.id);
    const [profile] = await db.select({ id: profiles.id }).from(profiles).where(eq(profiles.userId, user.id)).limit(1);
    writeMemberCookie(res, session.token, Math.floor(MEMBER_SESSION_MS / 1000));
    res.json(VerifyMemberOtpResponse.parse({ userId: user.id, phone: user.phone, profileId: profile?.id ?? null }));
  } catch (error) {
    req.log.error({ err: error }, "OTP verification failed");
    res.status(503).json({ error: "Unable to verify the code right now." });
  }
});

router.get("/auth/session", async (req, res): Promise<void> => {
  const member = await getMemberIdentity(req);
  if (!member) {
    res.status(401).json({ error: "Member sign-in required." });
    return;
  }
  const [profile] = await db.select({ id: profiles.id }).from(profiles).where(eq(profiles.userId, member.id)).limit(1);
  res.json(GetMemberSessionResponse.parse({ userId: member.id, phone: member.phone, profileId: profile?.id ?? null }));
});

router.post("/auth/logout", async (req, res): Promise<void> => {
  const token = readMemberCookie(req);
  if (token) {
    await db.update(memberSessions).set({ revokedAt: new Date() })
      .where(and(eq(memberSessions.tokenHash, digestSessionToken(token)), isNull(memberSessions.revokedAt)));
  }
  writeMemberCookie(res, "", 0);
  res.json(LogoutMemberResponse.parse({ ok: true }));
});

export default router;
