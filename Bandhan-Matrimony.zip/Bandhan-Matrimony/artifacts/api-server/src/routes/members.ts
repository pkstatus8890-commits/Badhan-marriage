import { Router, type IRouter } from "express";
import {
  and, asc, count, desc, eq, gt, gte, ilike, inArray, lt, ne, notInArray, or, sql,
} from "drizzle-orm";
import {
  BlockMemberBody, BlockMemberResponse, GetMemberProfileParams, GetMemberProfileResponse,
  GetMyMarriageProfileResponse, ListConversationMessagesParams, ListConversationMessagesResponse,
  ListMemberConversationsResponse, ListMemberRequestsResponse, ReportMemberBody,
  ReportMemberResponse, RespondToMemberInterestBody, RespondToMemberInterestParams,
  RespondToMemberInterestResponse, SaveMyMarriageProfileBody, SaveMyMarriageProfileResponse,
  SearchMemberProfilesQueryParams, SearchMemberProfilesResponse, SendConversationMessageBody,
  SendConversationMessageParams, SendConversationMessageResponse, SendMemberInterestBody,
  SendMemberInterestResponse, SuggestCommunityBody, SuggestCommunityResponse,
} from "@workspace/api-zod";
import {
  appSettings, castesCommunities, conversations, db, matrimonialRequests, messages,
  profilePhotos, profiles, reports, subscriptionPlans, subscriptions, userBlocks, users,
} from "@workspace/db";
import { getMemberIdentity, type MemberIdentity } from "../lib/member-auth";

const router: IRouter = Router();
type ProfileRow = {
  id: string; userId: string; name: string; dateOfBirth: string; gender: string;
  city: string; district: string; state: string; religion: string; communityId: string | null;
  community: string | null; subCommunity: string; privateAddress: string; education: string;
  profession: string; maritalStatus: string; gotra: string; height: string; family: string;
  about: string; partnerPreference: string; approvalStatus: string; rejectionReason: string | null;
  activityStatus: string;
};

function ageFromDate(dob: string): number {
  const birth = new Date(`${dob}T00:00:00Z`);
  const now = new Date();
  let age = now.getUTCFullYear() - birth.getUTCFullYear();
  if (now.getUTCMonth() < birth.getUTCMonth() || (now.getUTCMonth() === birth.getUTCMonth() && now.getUTCDate() < birth.getUTCDate())) age--;
  return age;
}

async function requireMember(req: Parameters<Parameters<IRouter["get"]>[1]>[0], res: Parameters<Parameters<IRouter["get"]>[1]>[1]): Promise<MemberIdentity | null> {
  const member = await getMemberIdentity(req);
  if (!member) {
    res.status(401).json({ error: "Member sign-in required." });
    return null;
  }
  return member;
}

async function getProfile(profileId: string): Promise<ProfileRow | null> {
  const rows = await db.select({
    id: profiles.id, userId: profiles.userId, name: profiles.name, dateOfBirth: profiles.dateOfBirth,
    gender: profiles.gender, city: profiles.city, district: profiles.district, state: profiles.state,
    religion: profiles.religion, communityId: profiles.communityId, community: castesCommunities.name,
    subCommunity: profiles.subCommunity, privateAddress: profiles.privateAddress, education: profiles.education,
    profession: profiles.profession, maritalStatus: profiles.maritalStatus, gotra: profiles.gotra,
    height: profiles.height, family: profiles.family, about: profiles.about,
    partnerPreference: profiles.partnerPreference, approvalStatus: profiles.approvalStatus,
    rejectionReason: profiles.rejectionReason, activityStatus: profiles.activityStatus,
  }).from(profiles).innerJoin(users, eq(profiles.userId, users.id))
    .leftJoin(castesCommunities, eq(profiles.communityId, castesCommunities.id))
    .where(and(eq(profiles.id, profileId), eq(users.status, "active")))
    .limit(1);
  return rows[0] ?? null;
}

async function profilePhotosFor(profileId: string, includePending = false) {
  const photos = await db.select({
    id: profilePhotos.id, objectPath: profilePhotos.objectPath, isPrimary: profilePhotos.isPrimary,
    moderationStatus: profilePhotos.moderationStatus,
  }).from(profilePhotos).where(includePending
    ? eq(profilePhotos.profileId, profileId)
    : and(eq(profilePhotos.profileId, profileId), eq(profilePhotos.moderationStatus, "approved")))
    .orderBy(desc(profilePhotos.isPrimary), asc(profilePhotos.createdAt));
  return photos.map((photo) => ({
    ...photo,
    url: `/api/storage/objects/${photo.objectPath.slice("/objects/".length)}`,
  }));
}

function toPublicProfile(row: ProfileRow, photos: Array<{ id: string; objectPath: string; isPrimary: boolean }>) {
  return {
    id: row.id, name: row.name, dateOfBirth: row.dateOfBirth, age: ageFromDate(row.dateOfBirth),
    gender: row.gender, city: row.city, district: row.district, state: row.state, religion: row.religion,
    communityId: row.communityId, community: row.community, subCommunity: row.subCommunity,
    education: row.education, profession: row.profession, maritalStatus: row.maritalStatus,
    gotra: row.gotra, height: row.height, family: row.family, about: row.about,
    partnerPreference: row.partnerPreference, photos,
  };
}

async function getOwnProfile(member: MemberIdentity): Promise<ProfileRow | null> {
  const rows = await db.select({ id: profiles.id }).from(profiles).where(eq(profiles.userId, member.id)).limit(1);
  return rows[0] ? getProfile(rows[0].id) : null;
}

async function profileForUser(userId: string) {
  const rows = await db.select({ id: profiles.id }).from(profiles).where(eq(profiles.userId, userId)).limit(1);
  return rows[0] ?? null;
}

async function isBlockedBetween(userA: string, userB: string): Promise<boolean> {
  const rows = await db.select({ id: userBlocks.id }).from(userBlocks).where(or(
    and(eq(userBlocks.blockerUserId, userA), eq(userBlocks.blockedUserId, userB)),
    and(eq(userBlocks.blockerUserId, userB), eq(userBlocks.blockedUserId, userA)),
  )).limit(1);
  return rows.length > 0;
}

router.get("/profiles", async (req, res): Promise<void> => {
  const member = await requireMember(req, res);
  if (!member) return;
  const parsed = SearchMemberProfilesQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: "Search filters are invalid." });
    return;
  }
  const filters = [
    eq(profiles.approvalStatus, "approved"),
    eq(profiles.activityStatus, "active"),
    eq(users.status, "active"),
    ne(profiles.userId, member.id),
  ];
  const q = parsed.data.q?.trim();
  if (q) {
    const match = `%${q}%`;
    filters.push(or(
      ilike(profiles.name, match), ilike(profiles.city, match), ilike(profiles.district, match),
      ilike(profiles.education, match), ilike(profiles.profession, match),
      ilike(castesCommunities.name, match), ilike(profiles.subCommunity, match),
    )!);
  }
  if (parsed.data.gender) filters.push(eq(profiles.gender, parsed.data.gender));
  if (parsed.data.city) filters.push(ilike(profiles.city, `%${parsed.data.city.trim()}%`));
  if (parsed.data.district) filters.push(ilike(profiles.district, `%${parsed.data.district.trim()}%`));
  if (parsed.data.state) filters.push(ilike(profiles.state, `%${parsed.data.state.trim()}%`));
  if (parsed.data.communityId) filters.push(eq(profiles.communityId, parsed.data.communityId));
  if (parsed.data.education) filters.push(ilike(profiles.education, `%${parsed.data.education.trim()}%`));
  if (parsed.data.profession) filters.push(ilike(profiles.profession, `%${parsed.data.profession.trim()}%`));
  if (parsed.data.maritalStatus) filters.push(eq(profiles.maritalStatus, parsed.data.maritalStatus));
  const ageExpression = sql<number>`extract(year from age(current_date, ${profiles.dateOfBirth}::date))`;
  if (parsed.data.minAge != null) filters.push(gte(ageExpression, parsed.data.minAge));
  if (parsed.data.maxAge != null) filters.push(sql`${ageExpression} <= ${parsed.data.maxAge}`);
  const blockRows = await db.select({ blocker: userBlocks.blockerUserId, blocked: userBlocks.blockedUserId }).from(userBlocks)
    .where(or(eq(userBlocks.blockerUserId, member.id), eq(userBlocks.blockedUserId, member.id)));
  const blockedUserIds = blockRows.map((row) => row.blocker === member.id ? row.blocked : row.blocker);
  if (blockedUserIds.length) filters.push(notInArray(profiles.userId, blockedUserIds));
  const rows = await db.select({ id: profiles.id }).from(profiles)
    .innerJoin(users, eq(profiles.userId, users.id))
    .leftJoin(castesCommunities, eq(profiles.communityId, castesCommunities.id))
    .where(and(...filters))
    .orderBy(desc(profiles.approvedAt), desc(profiles.createdAt))
    .limit(parsed.data.limit ?? 30)
    .offset(parsed.data.offset ?? 0);
  const output = await Promise.all(rows.map(async ({ id }) => {
    const profile = await getProfile(id);
    if (!profile) return null;
    return toPublicProfile(profile, await profilePhotosFor(id));
  }));
  res.json(SearchMemberProfilesResponse.parse(output.filter(Boolean)));
});

router.get("/profiles/:profileId", async (req, res): Promise<void> => {
  const member = await requireMember(req, res);
  if (!member) return;
  const params = GetMemberProfileParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: "Invalid profile identifier." });
    return;
  }
  const row = await getProfile(params.data.profileId);
  if (!row || row.approvalStatus !== "approved" || row.activityStatus !== "active") {
    res.status(404).json({ error: "Profile not found." });
    return;
  }
  if (await isBlockedBetween(member.id, row.userId)) {
    res.status(404).json({ error: "Profile not found." });
    return;
  }
  res.json(GetMemberProfileResponse.parse(toPublicProfile(row, await profilePhotosFor(row.id))));
});

router.get("/me/profile", async (req, res): Promise<void> => {
  const member = await requireMember(req, res);
  if (!member) return;
  const row = await getOwnProfile(member);
  if (!row) {
    res.status(404).json({ error: "Marriage profile not found." });
    return;
  }
  res.json(GetMyMarriageProfileResponse.parse({
    ...toPublicProfile(row, await profilePhotosFor(row.id, true)),
    privateAddress: row.privateAddress,
    approvalStatus: row.approvalStatus,
    rejectionReason: row.rejectionReason,
  }));
});

router.put("/me/profile", async (req, res): Promise<void> => {
  const member = await requireMember(req, res);
  if (!member) return;
  const parsed = SaveMyMarriageProfileBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.issues[0]?.message ?? "Profile details are invalid." });
    return;
  }
  const body = parsed.data;
  const dateOfBirth = body.dateOfBirth.toISOString().slice(0, 10);
  const dob = new Date(`${dateOfBirth}T00:00:00Z`);
  if (Number.isNaN(dob.getTime()) || ageFromDate(dateOfBirth) < 18) {
    res.status(400).json({ error: "Marriage profiles are available only to adults aged 18 or older." });
    return;
  }
  const [community] = await db.select({ id: castesCommunities.id }).from(castesCommunities)
    .where(and(eq(castesCommunities.id, body.communityId), eq(castesCommunities.active, true))).limit(1);
  if (!community) {
    res.status(400).json({ error: "Choose an available community before saving your marriage profile." });
    return;
  }
  const existing = await profileForUser(member.id);
  const values = {
    name: body.name.trim(), dateOfBirth, gender: body.gender.trim(),
    city: body.city.trim(), district: body.district.trim(), state: body.state.trim(),
    religion: body.religion.trim(), communityId: body.communityId, subCommunity: body.subCommunity.trim(),
    privateAddress: body.privateAddress.trim(), education: body.education.trim(),
    profession: body.profession.trim(), maritalStatus: body.maritalStatus.trim(),
    gotra: body.gotra?.trim() ?? "", height: body.height?.trim() ?? "",
    family: body.family?.trim() ?? "", about: body.about?.trim() ?? "",
    partnerPreference: body.partnerPreference?.trim() ?? "",
    approvalStatus: "pending", rejectionReason: null, approvedAt: null, activityStatus: "active",
    updatedAt: new Date(),
  };
  let profileId: string;
  if (existing) {
    const [updated] = await db.update(profiles).set(values).where(eq(profiles.id, existing.id)).returning({ id: profiles.id });
    profileId = updated.id;
  } else {
    const [created] = await db.insert(profiles).values({ userId: member.id, ...values }).returning({ id: profiles.id });
    profileId = created.id;
  }
  const row = await getProfile(profileId);
  if (!row) {
    res.status(500).json({ error: "Unable to load the saved profile." });
    return;
  }
  res.json(SaveMyMarriageProfileResponse.parse({
    ...toPublicProfile(row, await profilePhotosFor(row.id, true)),
    privateAddress: row.privateAddress,
    approvalStatus: row.approvalStatus,
    rejectionReason: row.rejectionReason,
  }));
});

router.get("/requests", async (req, res): Promise<void> => {
  const member = await requireMember(req, res);
  if (!member) return;
  const own = await profileForUser(member.id);
  if (!own) {
    res.json(ListMemberRequestsResponse.parse({ sent: [], received: [] }));
    return;
  }
  const [sent, received] = await Promise.all([
    db.select().from(matrimonialRequests).where(eq(matrimonialRequests.fromProfileId, own.id)).orderBy(desc(matrimonialRequests.createdAt)).limit(500),
    db.select().from(matrimonialRequests).where(eq(matrimonialRequests.toProfileId, own.id)).orderBy(desc(matrimonialRequests.createdAt)).limit(500),
  ]);
  const ids = [...new Set([...sent.map((r) => r.toProfileId), ...received.map((r) => r.fromProfileId)])];
  const others = ids.length ? await db.select({ id: profiles.id, name: profiles.name, city: profiles.city, community: castesCommunities.name })
    .from(profiles).leftJoin(castesCommunities, eq(profiles.communityId, castesCommunities.id)).where(inArray(profiles.id, ids)) : [];
  const names = new Map(others.map((p) => [p.id, p]));
  const format = (r: typeof sent[number], side: "sent" | "received") => {
    const profileId = side === "sent" ? r.toProfileId : r.fromProfileId;
    return { ...r, profileId, member: names.get(profileId)?.name ?? "", city: names.get(profileId)?.city ?? "", community: names.get(profileId)?.community ?? null };
  };
  res.json(ListMemberRequestsResponse.parse({
    sent: sent.map((r) => format(r, "sent")),
    received: received.map((r) => format(r, "received")),
  }));
});

router.post("/requests", async (req, res): Promise<void> => {
  const member = await requireMember(req, res);
  if (!member) return;
  const parsed = SendMemberInterestBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Choose a profile to send interest to." });
    return;
  }
  const from = await getOwnProfile(member);
  const target = await getProfile(parsed.data.profileId);
  if (!from || from.approvalStatus !== "approved" || from.activityStatus !== "active") {
    res.status(403).json({ error: "Your marriage profile must be approved before sending interest." });
    return;
  }
  if (!target || target.approvalStatus !== "approved" || target.activityStatus !== "active" || target.userId === member.id) {
    res.status(404).json({ error: "That profile is not available." });
    return;
  }
  if (await isBlockedBetween(member.id, target.userId)) {
    res.status(404).json({ error: "That profile is not available." });
    return;
  }
  try {
    const [request] = await db.insert(matrimonialRequests).values({ fromProfileId: from.id, toProfileId: target.id }).returning();
    res.status(201).json(SendMemberInterestResponse.parse(request));
  } catch {
    res.status(409).json({ error: "An interest request already exists for this profile." });
  }
});

router.patch("/requests/:requestId", async (req, res): Promise<void> => {
  const member = await requireMember(req, res);
  if (!member) return;
  const params = RespondToMemberInterestParams.safeParse(req.params);
  const parsed = RespondToMemberInterestBody.safeParse(req.body);
  if (!params.success || !parsed.success) {
    res.status(400).json({ error: "The request response is invalid." });
    return;
  }
  const own = await profileForUser(member.id);
  if (!own) {
    res.status(404).json({ error: "Marriage profile not found." });
    return;
  }
  const [request] = await db.update(matrimonialRequests)
    .set({ status: parsed.data.status, updatedAt: new Date() })
    .where(and(
      eq(matrimonialRequests.id, params.data.requestId),
      eq(matrimonialRequests.toProfileId, own.id),
      eq(matrimonialRequests.status, "pending"),
    ))
    .returning();
  if (!request) {
    res.status(404).json({ error: "Request not found or no longer available." });
    return;
  }
  let conversationId: string | null = null;
  if (request.status === "accepted") {
    const [conversation] = await db.insert(conversations).values({
      requestId: request.id, profileAId: request.fromProfileId, profileBId: request.toProfileId,
    }).onConflictDoNothing().returning({ id: conversations.id });
    if (conversation) conversationId = conversation.id;
    else {
      const [existing] = await db.select({ id: conversations.id }).from(conversations).where(eq(conversations.requestId, request.id)).limit(1);
      conversationId = existing?.id ?? null;
    }
  }
  res.json(RespondToMemberInterestResponse.parse({ ...request, conversationId }));
});

router.get("/conversations", async (req, res): Promise<void> => {
  const member = await requireMember(req, res);
  if (!member) return;
  const own = await profileForUser(member.id);
  if (!own) {
    res.json(ListMemberConversationsResponse.parse([]));
    return;
  }
  const rows = await db.select().from(conversations).where(and(
    or(eq(conversations.profileAId, own.id), eq(conversations.profileBId, own.id)),
    eq(conversations.status, "active"),
  )).orderBy(desc(conversations.createdAt)).limit(500);
  const otherIds = rows.map((row) => row.profileAId === own.id ? row.profileBId : row.profileAId);
  const others = otherIds.length ? await db.select({
    id: profiles.id, name: profiles.name, city: profiles.city, photo: profilePhotos.objectPath,
  }).from(profiles).leftJoin(profilePhotos, and(eq(profilePhotos.profileId, profiles.id), eq(profilePhotos.isPrimary, true), eq(profilePhotos.moderationStatus, "approved")))
    .where(inArray(profiles.id, otherIds)) : [];
  const otherMap = new Map(others.map((profile) => [profile.id, profile]));
  const messageCounts = rows.length ? await db.select({ conversationId: messages.conversationId, total: count() }).from(messages)
    .where(inArray(messages.conversationId, rows.map((row) => row.id))).groupBy(messages.conversationId) : [];
  const countMap = new Map(messageCounts.map((entry) => [entry.conversationId, entry.total]));
  const output = rows.map((row) => {
    const otherId = row.profileAId === own.id ? row.profileBId : row.profileAId;
    return { ...row, participant: otherMap.get(otherId)?.name ?? "", city: otherMap.get(otherId)?.city ?? "", photo: otherMap.get(otherId)?.photo ?? null, messageCount: countMap.get(row.id) ?? 0 };
  });
  res.json(ListMemberConversationsResponse.parse(output));
});

async function getActiveConversation(member: MemberIdentity, conversationId: string) {
  const own = await profileForUser(member.id);
  if (!own) return null;
  const rows = await db.select().from(conversations).where(and(
    eq(conversations.id, conversationId),
    or(eq(conversations.profileAId, own.id), eq(conversations.profileBId, own.id)),
    eq(conversations.status, "active"),
  )).limit(1);
  return rows[0] ? { ...rows[0], ownProfileId: own.id } : null;
}

router.get("/conversations/:conversationId/messages", async (req, res): Promise<void> => {
  const member = await requireMember(req, res);
  if (!member) return;
  const params = ListConversationMessagesParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: "Invalid conversation." });
    return;
  }
  const conversation = await getActiveConversation(member, params.data.conversationId);
  if (!conversation) {
    res.status(404).json({ error: "Conversation not available." });
    return;
  }
  const rows = await db.select({
    id: messages.id, conversationId: messages.conversationId,
    senderProfileId: messages.senderProfileId, content: messages.content, createdAt: messages.createdAt,
  }).from(messages).where(eq(messages.conversationId, conversation.id))
    .orderBy(asc(messages.createdAt)).limit(500);
  res.json(ListConversationMessagesResponse.parse(rows));
});

router.post("/conversations/:conversationId/messages", async (req, res): Promise<void> => {
  const member = await requireMember(req, res);
  if (!member) return;
  const params = SendConversationMessageParams.safeParse(req.params);
  const parsed = SendConversationMessageBody.safeParse(req.body);
  if (!params.success || !parsed.success) {
    res.status(400).json({ error: "Message is invalid." });
    return;
  }
  const conversation = await getActiveConversation(member, params.data.conversationId);
  if (!conversation) {
    res.status(404).json({ error: "Conversation not available." });
    return;
  }
  const settings = await db.select({ key: appSettings.key, value: appSettings.value }).from(appSettings)
    .where(inArray(appSettings.key, ["free_message_limit", "premium_message_limit", "premium_unlimited_messaging"]));
  const settingsMap = new Map(settings.map((setting) => [setting.key, setting.value]));
  const [subscription] = await db.select({
    limit: subscriptionPlans.messageLimit,
    unlimited: subscriptionPlans.unlimitedMessaging,
  }).from(subscriptions).innerJoin(subscriptionPlans, eq(subscriptions.planId, subscriptionPlans.id))
    .where(and(
      eq(subscriptions.userId, member.id), eq(subscriptions.status, "active"),
      gt(subscriptions.expiresAt, new Date()), eq(subscriptionPlans.active, true),
    )).orderBy(desc(subscriptions.expiresAt)).limit(1);
  const unlimited = subscription?.unlimited === true;
  const configuredLimit = subscription
    ? subscription.limit ?? Number(settingsMap.get("premium_message_limit") ?? settingsMap.get("free_message_limit") ?? 5)
    : Number(settingsMap.get("free_message_limit") ?? 5);
  if (!unlimited) {
    const sent = await db.select({ total: count() }).from(messages).where(and(
      eq(messages.conversationId, conversation.id),
      eq(messages.senderProfileId, conversation.ownProfileId),
    ));
    if ((sent[0]?.total ?? 0) >= configuredLimit) {
      res.status(403).json({ error: "Your chat limit for this connection has been reached. Choose a plan to continue." });
      return;
    }
  }
  const [message] = await db.insert(messages).values({
    conversationId: conversation.id, senderProfileId: conversation.ownProfileId,
    content: parsed.data.content.trim(),
  }).returning({
    id: messages.id, conversationId: messages.conversationId,
    senderProfileId: messages.senderProfileId, content: messages.content, createdAt: messages.createdAt,
  });
  res.status(201).json(SendConversationMessageResponse.parse(message));
});

router.post("/reports", async (req, res): Promise<void> => {
  const member = await requireMember(req, res);
  if (!member) return;
  const parsed = ReportMemberBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Report details are invalid." });
    return;
  }
  const [targetProfile] = await db.select({ userId: profiles.userId }).from(profiles)
    .innerJoin(users, eq(profiles.userId, users.id))
    .where(and(eq(profiles.id, parsed.data.profileId), eq(users.status, "active"))).limit(1);
  if (!targetProfile) {
    res.status(404).json({ error: "Member profile not found." });
    return;
  }
  if (targetProfile.userId === member.id) {
    res.status(400).json({ error: "You cannot report your own account." });
    return;
  }
  const [report] = await db.insert(reports).values({
    reporterUserId: member.id, reportedUserId: targetProfile.userId, reason: parsed.data.reason.trim(),
    description: parsed.data.description?.trim() ?? "",
  }).returning({ id: reports.id, status: reports.status, createdAt: reports.createdAt });
  res.status(201).json(ReportMemberResponse.parse(report));
});

router.post("/blocks", async (req, res): Promise<void> => {
  const member = await requireMember(req, res);
  if (!member) return;
  const parsed = BlockMemberBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Choose another member to block." });
    return;
  }
  const [target] = await db.select({ id: users.id }).from(profiles)
    .innerJoin(users, eq(profiles.userId, users.id))
    .where(and(eq(profiles.id, parsed.data.profileId), eq(users.status, "active"))).limit(1);
  if (!target || target.id === member.id) {
    res.status(target ? 400 : 404).json({ error: target ? "You cannot block your own account." : "Member profile not found." });
    return;
  }
  await db.insert(userBlocks).values({ blockerUserId: member.id, blockedUserId: target.id }).onConflictDoNothing();
  const own = await profileForUser(member.id);
  const other = await profileForUser(target.id);
  if (own && other) {
    await db.update(matrimonialRequests).set({ status: "blocked", updatedAt: new Date() })
      .where(or(
        and(eq(matrimonialRequests.fromProfileId, own.id), eq(matrimonialRequests.toProfileId, other.id)),
        and(eq(matrimonialRequests.fromProfileId, other.id), eq(matrimonialRequests.toProfileId, own.id)),
      ));
    await db.update(conversations).set({ status: "blocked" })
      .where(or(
        and(eq(conversations.profileAId, own.id), eq(conversations.profileBId, other.id)),
        and(eq(conversations.profileAId, other.id), eq(conversations.profileBId, own.id)),
      ));
  }
  res.status(201).json(BlockMemberResponse.parse({ ok: true }));
});

router.post("/communities/suggest", async (req, res): Promise<void> => {
  const member = await requireMember(req, res);
  if (!member) return;
  const parsed = SuggestCommunityBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Enter a community name." });
    return;
  }
  const name = parsed.data.name.trim().replace(/\s+/g, " ");
  const [created] = await db.insert(castesCommunities).values({ name, stateCoverage: [] })
    .onConflictDoNothing().returning({ id: castesCommunities.id, name: castesCommunities.name });
  let community = created;
  if (!community) {
    const [existing] = await db.select({ id: castesCommunities.id, name: castesCommunities.name }).from(castesCommunities)
      .where(and(eq(castesCommunities.name, name), eq(castesCommunities.active, true))).limit(1);
    if (!existing) {
      res.status(409).json({ error: "That community already exists but is not available yet. Contact support for review." });
      return;
    }
    community = existing;
  }
  res.status(201).json(SuggestCommunityResponse.parse({ ...community, category: null }));
});

export default router;
