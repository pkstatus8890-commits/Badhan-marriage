import { Readable } from "node:stream";
import { and, count, eq } from "drizzle-orm";
import { Router, type IRouter } from "express";
import {
  AttachMyProfilePhotoBody, AttachMyProfilePhotoResponse, DeleteMyProfilePhotoParams,
  DeleteMyProfilePhotoResponse, RequestProfilePhotoUploadUrlBody, RequestProfilePhotoUploadUrlResponse,
} from "@workspace/api-zod";
import { db, profilePhotos, profiles } from "@workspace/db";
import { getMemberIdentity } from "../lib/member-auth";
import { getAdminIdentity } from "./admin";
import { ObjectNotFoundError, ObjectStorageService } from "../lib/objectStorage";

const router: IRouter = Router();
const storage = new ObjectStorageService();
const allowedTypes = new Set(["image/jpeg", "image/png", "image/webp"]);

async function memberProfileId(userId: string): Promise<string | null> {
  const [profile] = await db.select({ id: profiles.id }).from(profiles).where(eq(profiles.userId, userId)).limit(1);
  return profile?.id ?? null;
}

router.post("/storage/uploads/request-url", async (req, res): Promise<void> => {
  const member = await getMemberIdentity(req);
  if (!member) {
    res.status(401).json({ error: "Member sign-in required." });
    return;
  }
  const parsed = RequestProfilePhotoUploadUrlBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Choose a JPG, PNG, or WebP image under 10 MB." });
    return;
  }
  if (!allowedTypes.has(parsed.data.contentType)) {
    res.status(400).json({ error: "Only JPG, PNG, and WebP profile images are accepted." });
    return;
  }
  if (parsed.data.size > 10 * 1024 * 1024) {
    res.status(413).json({ error: "Profile images must be 10 MB or smaller." });
    return;
  }
  const profileId = await memberProfileId(member.id);
  if (!profileId) {
    res.status(400).json({ error: "Create your marriage profile before adding photos." });
    return;
  }
  const [photoCount] = await db.select({ total: count() }).from(profilePhotos).where(eq(profilePhotos.profileId, profileId));
  if ((photoCount?.total ?? 0) >= 6) {
    res.status(400).json({ error: "A profile can have up to six photos." });
    return;
  }
  try {
    const uploadURL = await storage.getObjectEntityUploadURL(profileId);
    const objectPath = storage.normalizeObjectEntityPath(uploadURL);
    res.json(RequestProfilePhotoUploadUrlResponse.parse({ uploadURL, objectPath }));
  } catch (error) {
    req.log.error({ err: error }, "Could not create a profile photo upload URL");
    res.status(503).json({ error: "Profile photo storage is currently unavailable." });
  }
});

router.post("/me/photos", async (req, res): Promise<void> => {
  const member = await getMemberIdentity(req);
  if (!member) {
    res.status(401).json({ error: "Member sign-in required." });
    return;
  }
  const parsed = AttachMyProfilePhotoBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid profile photo." });
    return;
  }
  const profileId = await memberProfileId(member.id);
  if (!profileId) {
    res.status(400).json({ error: "Create your marriage profile before adding photos." });
    return;
  }
  const { objectPath } = parsed.data;
  if (!objectPath.startsWith(`/objects/uploads/${profileId}/`)) {
    res.status(403).json({ error: "That upload was not created for your profile." });
    return;
  }
  const [photoCount] = await db.select({ total: count() }).from(profilePhotos).where(eq(profilePhotos.profileId, profileId));
  if ((photoCount?.total ?? 0) >= 6) {
    res.status(400).json({ error: "A profile can have up to six photos." });
    return;
  }
  try {
    const file = await storage.getObjectEntityFile(objectPath);
    const [metadata] = await file.getMetadata();
    const contentType = typeof metadata.contentType === "string" ? metadata.contentType : "";
    const size = Number(metadata.size ?? 0);
    if (!allowedTypes.has(contentType) || size <= 0 || size > 10 * 1024 * 1024) {
      await storage.deleteObject(objectPath).catch(() => undefined);
      res.status(400).json({ error: "The uploaded image is invalid or exceeds 10 MB." });
      return;
    }
    const existing = await db.select({ id: profilePhotos.id }).from(profilePhotos)
      .where(eq(profilePhotos.profileId, profileId)).limit(1);
    const isPrimary = existing.length === 0 || parsed.data.isPrimary === true;
    const [photo] = await db.transaction(async (tx) => {
      if (isPrimary) await tx.update(profilePhotos).set({ isPrimary: false }).where(eq(profilePhotos.profileId, profileId));
      return tx.insert(profilePhotos).values({
        profileId, objectPath, isPrimary, moderationStatus: "pending",
      }).returning({ id: profilePhotos.id, objectPath: profilePhotos.objectPath, isPrimary: profilePhotos.isPrimary, moderationStatus: profilePhotos.moderationStatus });
    });
    res.status(201).json(AttachMyProfilePhotoResponse.parse({
      ...photo, url: `/api/storage/objects/${objectPath.slice("/objects/".length)}`,
    }));
  } catch (error) {
    if (error instanceof ObjectNotFoundError) {
      res.status(400).json({ error: "The uploaded image could not be found. Try uploading it again." });
      return;
    }
    req.log.error({ err: error }, "Could not attach a profile photo");
    res.status(500).json({ error: "Could not save the profile photo." });
  }
});

router.delete("/me/photos/:photoId", async (req, res): Promise<void> => {
  const member = await getMemberIdentity(req);
  if (!member) {
    res.status(401).json({ error: "Member sign-in required." });
    return;
  }
  const parsed = DeleteMyProfilePhotoParams.safeParse(req.params);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid photo identifier." });
    return;
  }
  const profileId = await memberProfileId(member.id);
  const [photo] = profileId ? await db.select().from(profilePhotos)
    .where(and(eq(profilePhotos.id, parsed.data.photoId), eq(profilePhotos.profileId, profileId))).limit(1) : [];
  if (!photo) {
    res.status(404).json({ error: "Photo not found." });
    return;
  }
  try {
    await storage.deleteObject(photo.objectPath);
  } catch (error) {
    if (!(error instanceof ObjectNotFoundError)) {
      req.log.error({ err: error }, "Could not remove profile photo bytes");
      res.status(503).json({ error: "Photo storage is unavailable; the photo record was not removed." });
      return;
    }
  }
  await db.delete(profilePhotos).where(eq(profilePhotos.id, photo.id));
  res.json(DeleteMyProfilePhotoResponse.parse({ ok: true }));
});

router.get("/storage/objects/*path", async (req, res): Promise<void> => {
  const member = await getMemberIdentity(req);
  const admin = member ? null : await getAdminIdentity(req);
  if (!member && !admin) {
    res.status(401).json({ error: "Sign-in required." });
    return;
  }
  const raw = req.params.path;
  const relative = Array.isArray(raw) ? raw.join("/") : raw;
  const objectPath = `/objects/${relative}`;
  const [photo] = await db.select({
    ownerId: profiles.userId, approvalStatus: profiles.approvalStatus,
    activityStatus: profiles.activityStatus, moderationStatus: profilePhotos.moderationStatus,
  }).from(profilePhotos).innerJoin(profiles, eq(profilePhotos.profileId, profiles.id))
    .where(eq(profilePhotos.objectPath, objectPath)).limit(1);
  if (!photo) {
    res.status(404).json({ error: "Photo not found." });
    return;
  }
  const isOwner = member?.id === photo.ownerId;
  const mayReadApprovedPhoto = member && photo.moderationStatus === "approved" &&
    photo.approvalStatus === "approved" && photo.activityStatus === "active";
  if (!admin && !isOwner && !mayReadApprovedPhoto) {
    res.status(404).json({ error: "Photo not found." });
    return;
  }
  try {
    const file = await storage.getObjectEntityFile(objectPath);
    const response = await storage.downloadObject(file);
    res.status(response.status);
    response.headers.forEach((value, key) => res.setHeader(key, value));
    if (response.body) Readable.fromWeb(response.body as ReadableStream<Uint8Array>).pipe(res);
    else res.end();
  } catch (error) {
    if (error instanceof ObjectNotFoundError) {
      res.status(404).json({ error: "Photo not found." });
      return;
    }
    req.log.error({ err: error }, "Could not serve a profile photo");
    res.status(500).json({ error: "Could not serve the profile photo." });
  }
});

export default router;
